# Note per la nuova submission iOS

## Modifiche incluse

- I testi di accesso a fotocamera e microfono ora spiegano le funzioni concrete dell'app e danno esempi d'uso.
- Ho reso più chiara anche la descrizione della posizione, che nel progetto era generica.
- La configurazione Firebase usata dal wrapper è stata mantenuta per non interrompere le notifiche push.

## 2.3.10 — Riferimenti a store di terze parti

Il progetto nativo è un wrapper `WKWebView` e carica il sito remoto `https://vibraalienmatch.com`, configurato in `src/Vibra/Settings.swift`. Non incorpora il bundle web generato dal progetto Replit.

La scansione testuale del progetto nativo non ha trovato riferimenti allo store Android; anche la pagina pubblica di avvio controllata non ne mostra. Prima della nuova submission, verifica comunque il sito pubblicato nelle schermate accessibili dall'app e i metadati App Store: il contenuto caricato da `WKWebView` può cambiare senza ricompilare l'IPA.

## 2.3.4 — Anteprima video App Store

Nessun video di anteprima App Store era incluso nello ZIP. Questo punto non si corregge nel progetto Xcode né ricompilando l'IPA:

1. In App Store Connect apri **Previews and Screenshots** per la versione.
2. Se necessario seleziona **View All Sizes in Media Manager**.
3. Sostituisci ogni anteprima contestata con una registrazione diretta dello schermo dell'app, senza cornice, mockup o bordo del dispositivo.
4. Controlla ciascuna dimensione supportata prima di inviare di nuovo la build.

## Verifica della build

Il progetto va archiviato e firmato con Xcode su macOS. La creazione di questo ZIP non compila né firma un IPA.